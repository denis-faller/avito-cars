<?
$arModuleVersion = array(
	"VERSION" => "0.1.0",
	"VERSION_DATE" => "2020-07-13 09:00:00"
);
?>